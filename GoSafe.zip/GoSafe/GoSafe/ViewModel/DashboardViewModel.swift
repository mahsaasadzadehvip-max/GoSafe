//
//  DashboardViewModel.swift
//  GoSafe
//
//  Created by Foundation 25 on 30/01/26.
//
import Foundation
import MapKit
import Observation
import CoreLocation
import _MapKit_SwiftUI

@Observable
class DashboardViewModel: NSObject, CLLocationManagerDelegate, MKLocalSearchCompleterDelegate {
    let ulr = "https://api.minecrime.it/api/v1/crimes?city=Napoli&start=2025-01-01&end=2025-02-01&language=en"
    let urlfake = ""
    var locationManager = CLLocationManager()
    
    var position: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 40.8518, longitude: 14.2681),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
    )
    
    var searchResults: [MKMapItem] = []
    var searchText: String = ""
    var shouldRecenter: Bool = false
    
    private var completer = MKLocalSearchCompleter()
    var suggestions: [MKLocalSearchCompletion] = []
    var isSearching: Bool = false
    
    var crimes: [CrimeEvent] = []
    
    override init() {
        super.init()
        locationManager.delegate = self
        completer.delegate = self
        completer.resultTypes = .pointOfInterest
        
        loadCrimeData()
    }

    func checkLocationAuthorization() {
        if locationManager.authorizationStatus == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        }
    }
    
    func centerOnUser() { shouldRecenter = true }

    // MARK: - API REQUEST (Funzionante + Lettura Dati)
        func loadCrimeData() {

            let headers = [
              "X-API-Key": "d56ca4ea-0cf9-46c5-8360-c63094e08402",
              "Accept": "application/json"
            ]

            let request = NSMutableURLRequest(url: NSURL(string: ulr)! as URL,
                                                    cachePolicy: .useProtocolCachePolicy,
                                                timeoutInterval: 10.0)
            request.httpMethod = "GET"
            request.allHTTPHeaderFields = headers

            print("🚀 Richiesta partita...")

                    let session = URLSession.shared
                    let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { [weak self] (data, response, error) -> Void in
                        
                        if (error != nil) {
                            print("❌ Errore API: \(error as Any)")
                        } else {
                            let httpResponse = response as? HTTPURLResponse
                            print("📡 STATO HTTP: \(httpResponse?.statusCode ?? 0)")

                            if let data = data {
                                do {
                            
                                    let jsonObject = try JSONSerialization.jsonObject(with: data, options: [])
                                    let prettyData = try JSONSerialization.data(withJSONObject: jsonObject, options: [.prettyPrinted])
                                    
                                    if let prettyString = String(data: prettyData, encoding: .utf8) {
                                        print("\n✂️ --- JSON ORIGINALE DAL SERVER (COPIA DA QUI) --- ✂️\n")
                                        print(prettyString)
                                        print("\n✂️ --- FINE JSON --- ✂️\n")
                                    }
                                } catch {
                                    if let rawString = String(data: data, encoding: .utf8) {
                                        print("📦 JSON GREZZO (Non formattato): \(rawString)")
                                    }
                                }

                                do {
                                    let decodedCrimes = try JSONDecoder().decode([CrimeEvent].self, from: data)
                                    DispatchQueue.main.async {
                                        print("✅ App aggiornata con \(decodedCrimes.count) crimini.")
                                        self?.crimes = decodedCrimes
                                    }
                                } catch {
                                    print("⚠️ Errore Decodifica per l'App: \(error)")
                                }
                            }
                        }
                    })

                    dataTask.resume()
                }    
    func updateSuggestions() {
        guard !searchText.isEmpty, !isSearching else { suggestions = []; return }
        completer.queryFragment = searchText
        if let region = position.region { completer.region = region }
    }
    
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        Task { @MainActor in self.suggestions = completer.results }
    }
    
    func selectSuggestion(_ suggestion: MKLocalSearchCompletion) {
        searchText = suggestion.title + " " + suggestion.subtitle
        suggestions = []
        isSearching = true
        searchPlaces()
    }
    
    func searchPlaces() {
        guard !searchText.isEmpty else { return }
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        suggestions = []
        isSearching = true
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchText
        request.resultTypes = .pointOfInterest
        if let region = position.region { request.region = region }
        MKLocalSearch(request: request).start { [weak self] response, _ in
            DispatchQueue.main.async {
                self?.searchResults = response?.mapItems ?? []
                self?.isSearching = false
            }
        }
    }
    
    func clearSearch() { searchText = ""; suggestions = []; isSearching = false }
    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {}
}
