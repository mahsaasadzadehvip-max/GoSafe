//
//  EmergencyContact.swift
//  GoSafe
//
//  Created by Foundation 25 on 30/01/26.
//

import Foundation
import SwiftUI

// MARK: - Modello Dati
struct EmergencyContact: Identifiable {
    let id = UUID()
    let name: String
    let phoneNumber: String
    let icon: String
    let color: Color
}

