//
//  EmergencyContactView.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//
import Foundation
import SwiftUI

// MARK: - View Principale
struct EmergencyContactView: View {
    let contacts: [EmergencyContact] = [
        EmergencyContact(name: "Police", phoneNumber: "112", icon: "shield.fill", color: .blue),
        EmergencyContact(name: "Ambulance", phoneNumber: "118", icon: "cross.case.fill", color: .red)
    ]
    

    
    var body: some View {
        NavigationStack {
            ZStack {
    
                LinearGradient(colors: [Color.brandPrimary.opacity(0.95), Color.brandPrimary.opacity(0.35), .white],
                               startPoint: .top,
                               endPoint: .center)
                .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    
                    Text("Tap Call to quickly connect to the nearest service.").foregroundStyle(.black.opacity(0.6)).padding(.top).padding(.bottom, 70)
                    
                    List(contacts) { contact in
                        ContactRow(contact: contact)
                            .listRowBackground(Color.white.opacity(0.7))
                    }
                    .listStyle(.insetGrouped)
                    .scrollContentBackground(.hidden)
                    
                    Image("help")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 200)
                        .padding(.bottom, 20)
                }
            }
            .navigationTitle("Emergency Contacts")
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
        }
    }
}

// MARK: - Riga Contatto (Aggiornata con Colori Dinamici)
struct ContactRow: View {
    let contact: EmergencyContact
    
    var body: some View {
        Button(action: {
            makeCall(phoneNumber: contact.phoneNumber)
        }) {
            HStack(spacing: 16) {
                
              
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(contact.color.opacity(0.15))
                        .frame(width: 50, height: 50)
                    
                    Image(systemName: contact.icon)
                        .font(.title3)
                        .foregroundStyle(contact.color)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(contact.name)
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundStyle(.primary)
                    
                    Text(contact.phoneNumber)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                }
                
                Spacer()
                
               
                HStack(spacing: 6) {
                    Image(systemName: "phone.fill")
                        .font(.caption.bold())
                    Text("Call")
                        .font(.subheadline.bold())
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Color.brandPrimary)
                .foregroundStyle(.white)
                .clipShape(Capsule())
            }
            .padding(.vertical, 8) 
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
    
    private func makeCall(phoneNumber: String) {
        let cleanedNumber = phoneNumber.components(separatedBy: .whitespacesAndNewlines).joined()
        if let url = URL(string: "tel://\(cleanedNumber)") {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
            }
        }
    }
}

#Preview {
    EmergencyContactView()
}
