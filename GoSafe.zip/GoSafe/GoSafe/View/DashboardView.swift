//
//  DashboardView.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//

import SwiftUI
import MapKit

// MARK: - 3. MAIN DASHBOARD VIEW

struct DashboardView: View {
    @State private var viewModel = DashboardViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                // A. MAPPA
                FullMapLayer(viewModel: viewModel)
                    .ignoresSafeArea()
                
                // B. UI SUPERIORE
                VStack(spacing: 12) {
                    WelcomeHeaderView()
                    
                    VStack(spacing: 0) {
                        CustomSearchBar(text: $viewModel.searchText, onClear: {
                            viewModel.clearSearch()
                        }) {
                            viewModel.searchPlaces()
                        }
                        
                        if !viewModel.suggestions.isEmpty {
                            SuggestionListView(viewModel: viewModel)
                                .transition(.opacity)
                        }
                    }
                    .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 5)
                }
                .padding(.horizontal)
                .padding(.top, 10)
                
                // C. PULSANTE POSIZIONE
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: { viewModel.centerOnUser() }) {
                            Image(systemName: "location.fill")
                                .font(.title2)
                                .foregroundStyle(.blue)
                                .padding(14)
                                .background(.thickMaterial)
                                .clipShape(Circle())
                                .shadow(radius: 4)
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 40)
                    }
                }
            }
            .navigationTitle("RiskMap")
                        .navigationBarTitleDisplayMode(.inline)
                        .onAppear {
                            viewModel.checkLocationAuthorization()
                        }
                        .onChange(of: viewModel.searchText) {
                            viewModel.isSearching = false
                            viewModel.updateSuggestions()
                        }
        }
    }
}

// MARK: - 4. MAPPA UIKIT
struct FullMapLayer: UIViewRepresentable {
    @Bindable var viewModel: DashboardViewModel
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true
        mapView.showsCompass = false
        mapView.userTrackingMode = .none
        
        mapView.register(CrimeDotView.self, forAnnotationViewWithReuseIdentifier: CrimeDotView.reuseID)
        mapView.register(CrimeClusterView.self, forAnnotationViewWithReuseIdentifier: CrimeClusterView.reuseID)
        
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        if viewModel.shouldRecenter {
            mapView.setUserTrackingMode(.follow, animated: true)
            DispatchQueue.main.async { viewModel.shouldRecenter = false }
        }
        
        // AGGIORNAMENTO ANNOTAZIONI
        let currentAnnotations = mapView.annotations.compactMap { $0 as? CrimeAnnotation }
        if currentAnnotations.count != viewModel.crimes.count {
            mapView.removeAnnotations(currentAnnotations)
            
            let newAnnotations = viewModel.crimes.map { crime in
                let ann = CrimeAnnotation()
                ann.coordinate = crime.coordinate
                
                ann.category = crime.category ?? "Generico"
                ann.dateString = crime.date ?? "Data non disponibile"
                // ---------------------------
                
                return ann
            }
            mapView.addAnnotations(newAnnotations)
        }
        
        // AGGIORNAMENTO RICERCA
        let searchAnnotations = mapView.annotations.filter { !($0 is CrimeAnnotation) && !($0 is MKUserLocation) }
        mapView.removeAnnotations(searchAnnotations)
        
        let newSearchAnnotations = viewModel.searchResults.map { item in
            let annotation = MKPointAnnotation()
            annotation.coordinate = item.placemark.location?.coordinate ?? item.placemark.coordinate
            annotation.title = item.name
            return annotation
        }
        mapView.addAnnotations(newSearchAnnotations)
        
        if let first = viewModel.searchResults.first, viewModel.isSearching {
            let target = first.placemark.location?.coordinate ?? first.placemark.coordinate
            mapView.setRegion(MKCoordinateRegion(center: target, latitudinalMeters: 1000, longitudinalMeters: 1000), animated: true)
            DispatchQueue.main.async { viewModel.isSearching = false }
        }
    }
    
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: FullMapLayer
        init(_ parent: FullMapLayer) { self.parent = parent }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            if annotation is MKUserLocation { return nil }
            
            // 1. Crimine Singolo (ROSSO)
            if let _ = annotation as? CrimeAnnotation {
                let view = mapView.dequeueReusableAnnotationView(withIdentifier: CrimeDotView.reuseID, for: annotation) as! CrimeDotView
                view.canShowCallout = true
                view.clusteringIdentifier = "crime_cluster"
                return view
            }
            // 2. Cluster (ROSSO GRANDE)
            if let cluster = annotation as? MKClusterAnnotation {
                let view = mapView.dequeueReusableAnnotationView(withIdentifier: CrimeClusterView.reuseID, for: annotation) as! CrimeClusterView
                view.configure(count: cluster.memberAnnotations.count)
                return view
            }
            // 3. Ricerca
            let view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "searchResult")
            view.markerTintColor = .systemBlue
            return view
        }
        
        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            if let crimeAnnotation = view.annotation as? CrimeAnnotation {
                let label = UILabel()
                label.numberOfLines = 0
                let text = NSMutableAttributedString(string: "\(crimeAnnotation.category.uppercased())\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
                text.append(NSAttributedString(string: "Data: \(crimeAnnotation.dateString)", attributes: [.font: UIFont.systemFont(ofSize: 12), .foregroundColor: UIColor.gray]))
                label.attributedText = text
                view.detailCalloutAccessoryView = label
            }
        }
    }
}

// MARK: - CLASSI GRAFICHE PERSONALIZZATE

class CrimeDotView: MKAnnotationView {
    static let reuseID = "CrimeDotView"
    private let dotSize: CGFloat = 26
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        self.frame = CGRect(x: 0, y: 0, width: dotSize, height: dotSize)
        self.backgroundColor = UIColor.red.withAlphaComponent(0.45)
        self.layer.cornerRadius = dotSize / 2
        self.layer.borderWidth = 1.5
        self.layer.borderColor = UIColor.white.cgColor
    }
    required init?(coder: NSCoder) { fatalError() }
}

class CrimeClusterView: MKAnnotationView {
    static let reuseID = "CrimeClusterView"
    private let clusterSize: CGFloat = 50
    private let countLabel = UILabel()
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        self.frame = CGRect(x: 0, y: 0, width: clusterSize, height: clusterSize)
        self.backgroundColor = UIColor.red.withAlphaComponent(0.45)
        self.layer.cornerRadius = clusterSize / 2
        self.layer.borderWidth = 3
        self.layer.borderColor = UIColor.white.cgColor
        countLabel.frame = self.bounds
        countLabel.textAlignment = .center
        countLabel.textColor = .white
        countLabel.font = UIFont.boldSystemFont(ofSize: 16)
        self.addSubview(countLabel)
    }
    required init?(coder: NSCoder) { fatalError() }
    func configure(count: Int) { countLabel.text = "\(count)" }
}

// MARK: - 5. SUBVIEWS DI SUPPORTO

struct SuggestionListView: View {
    var viewModel: DashboardViewModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(viewModel.suggestions, id: \.self) { suggestion in
                    Button(action: { viewModel.selectSuggestion(suggestion) }) {
                        HStack(spacing: 12) {
                            Image(systemName: "mappin.circle.fill").foregroundStyle(.gray)
                            VStack(alignment: .leading) {
                                Text(suggestion.title).foregroundStyle(.primary)
                                if !suggestion.subtitle.isEmpty { Text(suggestion.subtitle).font(.caption).foregroundStyle(.secondary) }
                            }
                            Spacer()
                        }
                        .padding(12).contentShape(Rectangle())
                    }
                    Divider().padding(.leading, 40)
                }
            }.padding(.vertical, 5)
        }
        .frame(maxHeight: 250).background(.thickMaterial).clipShape(RoundedRectangle(cornerRadius: 12)).padding(.top, 2)
    }
}

struct CustomSearchBar: View {
    @Binding var text: String
    var onClear: () -> Void
    var onSubmit: () -> Void
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField("Where do you want to go?", text: $text).onSubmit { onSubmit() }
            if !text.isEmpty { Button(action: onClear) { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) } }
        }.padding(12).background(.thickMaterial).cornerRadius(12)
    }
}

struct WelcomeHeaderView: View {
    @AppStorage("userName") var userName: String = "Sara"
    @AppStorage("userEmoji") var userEmoji: String = "😎"
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Hi \(userName)!").font(.title3.bold()).foregroundStyle(.primary)
                Text("Let's travel 🌎").font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer()
            ZStack {
                Circle().fill(Color.indigo.opacity(0.1)).frame(width: 45, height: 45)
                Text(userEmoji).font(.title2)
            }
        }.padding().background(.thickMaterial).cornerRadius(16).shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}
//
//#Preview {
//    DashboardView()
//}
