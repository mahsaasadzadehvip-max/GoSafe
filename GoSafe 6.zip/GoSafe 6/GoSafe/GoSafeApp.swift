//
//  GoSafeApp.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//

import SwiftUI

@main
struct GoSafeApp: App {
    @AppStorage("hasCompletedOnboarding") var hasCompletedOnboarding: Bool = false
    @AppStorage("userName") var userName: String = ""
    
    @State private var showSplash: Bool = true

    var body: some Scene {
        WindowGroup {
            ZStack {
              
                if showSplash {
                    SplashView()
                        .transition(.opacity)
                } else {

                    if hasCompletedOnboarding {
                        MainTabView()
                            .transition(.opacity)
                    } else {
                        OnboardingFlowView()
                            .transition(.opacity)
                    }
                }
            }
            .animation(.easeInOut(duration: 0.5), value: showSplash)
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    withAnimation {
                        showSplash = false
                    }
                }
            }
        }
    }
}
