//
//  MainTabView.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//

import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            // Home / Map Tab
            DashboardView()
                .tabItem {
                    Label("Map", systemImage: "map.fill") // [cite: 33]
                }
            
            // Contacts Tab
            EmergencyContactView()
                .tabItem {
                    Label("Contacts", systemImage: "phone.fill") //
                }
            
            // Tips Tab
            SafetyTipsView()
                .tabItem {
                    Label("Tips", systemImage: "lightbulb.fill") //
                }
        }
    }
}

