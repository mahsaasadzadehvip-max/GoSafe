//
//  SplashView.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//

import Foundation
import SwiftUI

struct SplashView: View {
    var body: some View {
        ZStack(alignment: .top) {
            LinearGradient(colors: [Color.brandPrimary.opacity(0.95), Color.brandPrimary.opacity(0.35), .white],
                           startPoint: .top,
                           endPoint: .center).ignoresSafeArea()
            VStack(spacing: 0) {

                Spacer()
                Spacer()

                VStack(spacing: 30) {
                    Text("Move with confidence,\nANYWHERE!")
                        .font(.largeTitle.bold())
                        .foregroundStyle(Color.brandPrimary.opacity(17))
                        .multilineTextAlignment(.center).shadow(radius: 20)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.horizontal, 50)

                    
                    Image("onboard")  
                        .resizable()
                        .cornerRadius(50)
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .padding()

                }

                Spacer()
                Spacer()
            }
        }
    }
}

#Preview {
    SplashView()
}
