//
//  OnboardingFlowView.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//

import SwiftUI

// MARK: - DEFINIZIONE COLORE PERSONALIZZATO (#5B68AF)
extension Color {
    static let brandPrimary = Color(red: 91/255, green: 104/255, blue: 175/255)
}

struct OnboardingFlowView: View {
    @AppStorage("hasCompletedOnboarding") var hasCompletedOnboarding: Bool = false
    @AppStorage("userName") var userName: String = ""
    @AppStorage("userEmoji") var userEmoji: String = "😎"
    
    @State private var nameInput: String = ""
    @State private var emojiInput: String = "😎"
    
    @State private var showInfoSheet: Bool = true
    
    let avatars = ["😎", "😄", "😘", "🥳"]

    var body: some View {
        ZStack(alignment: .top) {
            
            LinearGradient(colors: [
                Color.brandPrimary.opacity(0.95),
                Color.brandPrimary.opacity(0.35),
                .white
            ],
            startPoint: .top,
            endPoint: .center)
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                ZStack(alignment: .top) {
            
                    Text("Let's get to know you!")
                        .font(.title2.bold())
                        .foregroundStyle(.white)
                        .padding(.top, 150)
                }
                .ignoresSafeArea(edges: .top)
                
                Spacer()
            }
            
            VStack(spacing: 40) {
                Spacer().frame(height: 160)
                
                VStack(spacing: 15) {
                    Text("Choose your avatar")
                        .font(.subheadline)
                        .foregroundStyle(Color.brandPrimary.opacity(0.9)).bold()
                    
                    HStack(spacing: 20) {
                        ForEach(avatars, id: \.self) { avatar in
                            Button(action: {
                                withAnimation(.spring()) {
                                    emojiInput = avatar
                                }
                            }) {
                                Text(avatar)
                                    .font(.system(size: 40))
                                    .frame(width: 65, height: 65)
                                    .background(emojiInput == avatar ? Color.white.opacity(0.3) : Color.white.opacity(0.1))
                                    .clipShape(Circle())
                                    .overlay(
                                        Circle()
                                            .stroke(emojiInput == avatar ? Color.white : Color.white.opacity(0.3), lineWidth: emojiInput == avatar ? 2 : 1)
                                    )
                                    .scaleEffect(emojiInput == avatar ? 1.1 : 1.0)
                            }
                        }
                    }
                }
                
               
                VStack(alignment: .center, spacing: 10) {
            
                    Text("What should we call you?")
                        .font(.headline)
                        .foregroundStyle(Color.brandPrimary).bold().padding(.top)
                    
                    HStack {
                        Image(systemName: "person.fill")
                            .foregroundStyle(.gray)
                        
                        TextField("Enter your name", text: $nameInput)
                            .foregroundStyle(.black)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
                    
                    Image("explore")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .padding()
                }
                .padding(.horizontal, 30)
            
                Spacer()
                
                Button(action: {
                    completeOnboarding()
                }) {
                    Text("Start")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                }
                .disabled(!isFormValid)
                .padding(.horizontal, 20)
                .padding(.bottom, 150)
                .buttonStyle(.glassProminent)
            }
        }
        .sheet(isPresented: $showInfoSheet) {
            InfoSheetView(onDismiss: {
                showInfoSheet = false
            })
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
    }
    
    var isFormValid: Bool {
        return !nameInput.isEmpty
    }
    
    func completeOnboarding() {
        userName = nameInput
        userEmoji = emojiInput
        withAnimation {
            hasCompletedOnboarding = true
        }
    }
}

struct InfoSheetView: View {
    var onDismiss: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 10) {
                Image(systemName: "map.circle.fill")
                    .font(.system(size: 60))
                    .foregroundStyle(Color.brandPrimary)
                    .padding(.top, 30)
                
                Text("Welcome to GoSafe")
                    .font(.title.bold())
            }
            .padding(.bottom, 20)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    InfoRow(icon: "shield.fill", text: "Identify safe and risky zones in your city.")
                    InfoRow(icon: "phone.fill", text: "Quickly access local emergency numbers.")
                    InfoRow(icon: "lightbulb.fill", text: "Get tips to move safely.")
                    InfoRow(icon: "exclamationmark.triangle.fill", text: "Use this app as a guide, but trust your instinct!")
                }
                .padding(.horizontal)
            }
            
            Spacer()
            
            Button(action: onDismiss) {
                Text("Got it, let's go!").foregroundStyle(Color.white)
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
            }.buttonStyle(.glassProminent)
            .padding(.horizontal, 30)
            .padding(.bottom, 20)
            .padding(.top, 10)
        }
    }
}

struct InfoRow: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Image(systemName: icon)
                .foregroundStyle(.orange)
                .frame(width: 24)
            
            Text(text)
                .font(.body)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.leading)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

#Preview {
    OnboardingFlowView()
}
