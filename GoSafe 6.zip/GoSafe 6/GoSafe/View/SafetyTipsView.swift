//
//  SafetyTipsView.swift
//  GoSafe
//
//  Created by Foundation 25 on 29/01/26.
//

import SwiftUI
import UIKit

struct SafetyTipsView: View {
    struct Tip: Identifiable {
        let id = UUID()
        let icon: String
        let title: String
        let detail: String
    }
    
    private let tips: [Tip] = [
        .init(icon: "bell.and.waves.left.and.right.fill", title: "Stay Alert", detail: "Be mindful of your surroundings, especially in unfamiliar areas."),
        .init(icon: "location.fill", title: "Share Your Location", detail: "Send your live location to a trusted friend when walking alone."),
        .init(icon: "moon.stars.fill", title: "Choose Well-Lit Routes", detail: "Prefer main streets and brighter paths at night."),
        .init(icon: "battery.100.bolt", title: "Keep Your Phone Ready", detail: "Charge your device before you go and keep emergency access available.")
    ]
    
    init() {
            
            let appearance = UINavigationBarAppearance()
            appearance.configureWithTransparentBackground()
            appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
            appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
            
            UINavigationBar.appearance().standardAppearance = appearance
            UINavigationBar.appearance().compactAppearance = appearance
            UINavigationBar.appearance().scrollEdgeAppearance = appearance
        }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    Image("Tips")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 230)
                        .padding(.top, 10)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Simple habits that help you move safely and confidently.")
                            .font(.subheadline)
                            .foregroundStyle(.black.opacity(0.7))
                    }
                    .padding(.horizontal, 16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    VStack(spacing: 12) {
                        ForEach(tips) { tip in
                            TipCard(tip: tip)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
            }
            .background {
                LinearGradient(colors: [Color.brandPrimary.opacity(0.95), Color.brandPrimary.opacity(0.35), .white],
                               startPoint: .top,
                               endPoint: .center)
                .ignoresSafeArea()
            }
            .navigationTitle("Safety Tips!")
        }
    }
}

// MARK: - Componente Card
struct TipCard: View {
    let tip: SafetyTipsView.Tip

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            AnimatedTipIcon(systemName: tip.icon)

            VStack(alignment: .leading, spacing: 6) {
                Text(tip.title)
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                Text(tip.detail)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

// MARK: - Icona Animata
struct AnimatedTipIcon: View {
    let systemName: String
    @State private var animate = false

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.orange.opacity(0.35), lineWidth: 2)
                .frame(width: 44, height: 44)
                .scaleEffect(animate ? 1.15 : 0.95)
                .opacity(animate ? 0.20 : 0.90)

            Circle()
                .fill(Color.orange.opacity(0.14))
                .frame(width: 44, height: 44)

            Image(systemName: systemName)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(Color.orange)
                .scaleEffect(animate ? 1.06 : 1.0)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true)) {
                animate = true
            }
        }
        .accessibilityHidden(true)
    }
}

#Preview {
    SafetyTipsView()
}
