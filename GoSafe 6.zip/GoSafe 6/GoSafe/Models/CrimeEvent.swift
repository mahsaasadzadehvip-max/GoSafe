//
//  CrimeEvent.swift
//  GoSafe
//
//  Created by Foundation 25 on 30/01/26.
//

import Foundation
import MapKit

// MARK: - CRIME EVENT MODEL
struct CrimeEvent: Identifiable, Decodable {
    let id: String?
    let date: String?
    let category: String?
    let coords: Coordinates?
    
    struct Coordinates: Decodable {
        let lat: Double
        let lon: Double
    }
    
    var safeId: String {
        return id ?? UUID().uuidString
    }
    
    var safeCategory: String {
        return category ?? "Segnalazione"
    }
    
    var safeDate: String {
        return date ?? "Data non disponibile"
    }
    
    var coordinate: CLLocationCoordinate2D {
        guard let lat = coords?.lat, let lon = coords?.lon else {
            // Se mancano le coordinate, restituisce 0,0 (in mezzo al mare)
            return CLLocationCoordinate2D(latitude: 0, longitude: 0)
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }
}

class CrimeAnnotation: MKPointAnnotation {
    var category: String = ""
    var dateString: String = ""
}
